/*
 * This program takes in no command-line arguments (if you put some in, they're
 * ignored).
 * It prints a "Hello World" message.
 */

#include <stdio.h>

int main() {
    // Note that printf doesn't automatically add a newline character.
    printf("Hello World");
    return 0;
}
